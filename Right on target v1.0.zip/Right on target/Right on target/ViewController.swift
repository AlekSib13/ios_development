//
//  ViewController.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 01.06.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var slider: UISlider!
    @IBOutlet var label: UILabel!
    @IBOutlet weak var insertedNumberOfRounds: UITextField!
    
    
    var number: Int = 0
    var round: Int = 1
    var points: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.label.text = String(self.round)
        self.number = Int.random(in: 1...50)
        print("The number: \(self.number)")
    }
    
    
    
    @IBAction func checkNumber() {
        guard let numberOfRounds = insertedNumberOfRounds.text, let numberOfRoundsInt = Int(numberOfRounds), numberOfRoundsInt > 0 else {return}
        
        print(numberOfRoundsInt)
        
        
        if self.round <= numberOfRoundsInt {
            let numSliderValue = Int(self.slider.value)
            if numSliderValue != self.number {
                if numSliderValue > self.number {
                    self.points += 50 - (numSliderValue - self.number)
                } else {self.points += 50 - (self.number - numSliderValue)
                }
            } else {self.points += 50}
            print("Current round \(self.round), Your choicee \(numSliderValue), Current score \(self.points)")
            self.round += 1
            if self.round <= numberOfRoundsInt {
                self.label.text = String(self.round)}
        } else {let alert = UIAlertController(title: "Game over", message: "Your score is \(self.points)", preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Repeat", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            restartGame()
        }
    }
    
    func restartGame() {
        self.number = Int.random(in: 1...50)
        self.round = 1
        self.points = 0
        self.label.text = String(self.round)
    }
    
}

