//
//  SceneTwoViewController.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 03.06.2021.
//

import UIKit

class SceneTwoViewController: UIViewController {
    
    
    
    
    override func loadView() {
        super.loadView()
        print("loadView")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear")
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("viewDidAppear")
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisapper")
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("viewDidDisappear")
    }

    
    @IBAction func backToTheGameScreen() {
        self.dismiss(animated: true, completion: nil)
    }

}
