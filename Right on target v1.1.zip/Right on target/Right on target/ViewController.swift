//
//  ViewController.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 01.06.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var slider: UISlider!
    @IBOutlet var label: UILabel!
    @IBOutlet weak var insertedNumberOfRounds: UITextField!
    
    
    var number: Int = 0
    var round: Int = 1
    var points: Int = 0
    
    override func loadView() {
        super.loadView()
        print("loadView")
        
        let versionLabel = UILabel(frame: CGRect(x: 25, y: 15, width: 100, height: 20))
        versionLabel.textColor = UIColor.systemGray
        versionLabel.text = "Version 1.1"
        self.view.addSubview(versionLabel)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad")
        
        self.label.text = String(self.round)
        self.number = Int.random(in: 1...50)
        print("The number: \(self.number)")
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear")
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("viewDidAppear")
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisapper")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("viewDidDissapper")
    }
    
    
    
    @IBAction func checkNumber() {
        guard let numberOfRounds = insertedNumberOfRounds.text, let numberOfRoundsInt = Int(numberOfRounds), numberOfRoundsInt > 0 else {return}
        
        print(numberOfRoundsInt)
        
        
        if self.round < numberOfRoundsInt {
            let numSliderValue = Int(self.slider.value)
            if numSliderValue != self.number {
                if numSliderValue > self.number {
                    self.points += 50 - (numSliderValue - self.number)
                } else {self.points += 50 - (self.number - numSliderValue)
                }
            } else {self.points += 50}
            print("Current round \(self.round), Your choicee \(numSliderValue), Current score \(self.points)")
            self.round += 1
            if self.round <= numberOfRoundsInt {
                self.label.text = String(self.round)}
        } else if self.round == numberOfRoundsInt {
            let numSliderValue = Int(self.slider.value)
            if numSliderValue != self.number {
                if numSliderValue > self.number {
                    self.points += 50 - (numSliderValue - self.number)
                } else {self.points += 50 - (self.number - numSliderValue)
                }
            } else {self.points += 50}
            print("Current round \(self.round), Your choicee \(numSliderValue), Current score \(self.points)")
            
            let alert = UIAlertController(title: "Game over", message: "Your score is \(self.points)", preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Repeat", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            restartGame()
        }
    }
    
    
//    if self.round <= numberOfRoundsInt {
//        let numSliderValue = Int(self.slider.value)
//        if numSliderValue != self.number {
//            if numSliderValue > self.number {
//                self.points += 50 - (numSliderValue - self.number)
//            } else {self.points += 50 - (self.number - numSliderValue)
//            }
//        } else {self.points += 50}
//        print("Current round \(self.round), Your choicee \(numSliderValue), Current score \(self.points)")
//        self.round += 1
//        if self.round <= numberOfRoundsInt {
//            self.label.text = String(self.round)}
//    } else {let alert = UIAlertController(title: "Game over", message: "Your score is \(self.points)", preferredStyle: .actionSheet)
//        alert.addAction(UIAlertAction(title: "Repeat", style: .default, handler: nil))
//        self.present(alert, animated: true, completion: nil)
//        restartGame()
//    }
//}
    
    
    
    func restartGame() {
        self.number = Int.random(in: 1...50)
        self.round = 1
        self.points = 0
        self.label.text = String(self.round)
    }
    
    @IBAction func showAboutInfo() {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let sceneTwoViewController = storyboard.instantiateViewController(identifier: "SceneTwoViewController")
        self.present(sceneTwoViewController, animated: true, completion: nil)
    }
    
}

