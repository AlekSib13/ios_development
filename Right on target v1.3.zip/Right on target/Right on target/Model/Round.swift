//
//  Round.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 11.06.2021.
//

import Foundation

protocol GameRoundProtocol {
    var score: Int {get}
    var currentSecretValue: Int {get}
    
    func calculateScore(selectedValue playerValue: Int)
}


class GameRound: GameRoundProtocol {
    var score: Int = 0
    var currentSecretValue: Int = 0
    init(secretValue: Int) {
        currentSecretValue = secretValue
    }
    
    
    func calculateScore(selectedValue playerValue: Int) {
        if playerValue > currentSecretValue {
            score += 50 - playerValue + currentSecretValue
        } else if playerValue < currentSecretValue {
            score += 50 - currentSecretValue + playerValue
        } else {
            score += 50
        }
    }
}
