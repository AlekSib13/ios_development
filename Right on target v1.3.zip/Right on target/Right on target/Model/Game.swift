//
//  Game.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 04.06.2021.
//

import Foundation

protocol GameProtocol {
    var score: Int {get}
    var currentRound: GameRoundProtocol! {get}
    var isGameEnded: Bool {get}
    var secretValueGenerator: ValueGeneratorProtocol {get}
    
    func restartGame()
    func startNewRound()
}


class Game: GameProtocol {
    var score: Int {
        var totalScore: Int = 0
        for round in listOfRounds {
            totalScore += round.score
        }
        return totalScore
    }
    var currentRound: GameRoundProtocol!
    var secretValueGenerator: ValueGeneratorProtocol
    var specificRound: Int = 0
    
    private var listOfRounds = [GameRoundProtocol]()
    var roundsCount: Int
    
    var isGameEnded: Bool {
        if roundsCount == listOfRounds.count {
            return true
        } else {return false}
    }
    
    
    init(valueGenerator: ValueGeneratorProtocol, rounds: Int)
    {secretValueGenerator = valueGenerator
        roundsCount = rounds
        startNewRound()
    }
    

    func restartGame() {
        specificRound = 0
        listOfRounds = []
        startNewRound()
    }
    
    func startNewRound() {
        specificRound += 1
        let newSecretValue = getNewSecretValue()
        currentRound = GameRound(secretValue: newSecretValue)
        listOfRounds.append(currentRound)
    }
    
    
    private func getNewSecretValue() -> Int {
        secretValueGenerator.generateRandomValue()
    }
    
    
}

