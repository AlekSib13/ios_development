//
//  RandomValueGenerator.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 11.06.2021.
//

import Foundation


protocol ValueGeneratorProtocol {
    func generateRandomValue() -> Int
}

class ValueGenerator: ValueGeneratorProtocol {
    
    private let startValue: Int
    private let endValue: Int
    
    init?(startValue: Int, endValue: Int) {
        self.startValue = startValue
        self.endValue = endValue
        
        guard startValue <= endValue else {return nil}
    }
    
    
    func generateRandomValue() -> Int {
        (startValue...endValue).randomElement()!
    }
}
