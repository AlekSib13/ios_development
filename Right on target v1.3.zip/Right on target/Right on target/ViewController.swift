//
//  ViewController.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 01.06.2021.
//

import UIKit

class ViewController: UIViewController {
    
    var game: Game!

    @IBOutlet var slider: UISlider!
    @IBOutlet var label: UILabel!
    @IBOutlet weak var insertedNumberOfRounds: UITextField!
    
    
    override func loadView() {
        super.loadView()
        
        let versionLabel = UILabel(frame: CGRect(x: 25, y: 15, width: 100, height: 20))
        versionLabel.textColor = UIColor.systemGray
        versionLabel.text = "Version 1.3"
        self.view.addSubview(versionLabel)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let generator = ValueGenerator(startValue: 1, endValue: 50)!
        game = Game(valueGenerator: generator, rounds: 1)
        updateLabels()
    }
    // MARK: interaction between View and Model
    @IBAction func checkNumber() {
        game.currentRound.calculateScore(selectedValue: Int(slider.value))
        let insertedValue = Int(insertedNumberOfRounds.text!) ?? 1
        if insertedValue != game.roundsCount {
            game.roundsCount = insertedValue
        }
        if game.isGameEnded {
            showAlert(gameScore: game.score)
            game.restartGame()
            updateLabels()
        }
        else {
            game.startNewRound()
            updateLabels()}
    }
        
    // MARK: update of the VIEW elements
    func updateLabels() {
        label.text = String(game.specificRound)
    }
    
    // MARK: alert message
    func showAlert(gameScore: Int) {
        let alert = UIAlertController(title: "Game over", message: "Your score is \(gameScore)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "New game", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    // MARK: transition to another scene
    @IBAction func aboutButton() {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let secondViewController = storyBoard.instantiateViewController(withIdentifier: "SceneTwoViewController")
        self.present(secondViewController, animated: true, completion: nil)
    }
    
}

