//
//  SceneTwoViewController.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 03.06.2021.
//

import UIKit

class SceneTwoViewController: UIViewController {
    
    
    
    
    override func loadView() {
        super.loadView()
        print("loadView second scene")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad second scene")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear second scene")
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("viewDidAppear second scene")
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisapper second scene")
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("viewDidDisappear second scene")
    }
    
    @IBAction func backToMainScreen() {
        self.dismiss(animated: true, completion: nil)
    }
    

}
