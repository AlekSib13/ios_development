//
//  SceneThreeViewController.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 04.06.2021.
//

import UIKit

class SceneThreeViewController: UIViewController {

    override func loadView() {
        super.loadView()
        print("loadView third scene")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad third scene")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear third scene")
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("viewDidAppear third scene")
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisapper third scene")
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("viewDidDisappear third scene")
    }

}
