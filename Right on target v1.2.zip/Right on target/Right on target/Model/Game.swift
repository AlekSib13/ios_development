//
//  Game.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 04.06.2021.
//

import Foundation

protocol GameProtocol {
    var score: Int {get}
    var currentSecretValue: Int {get}
    var insertedNumberOfRounds: Int {get}
    var isGameEnded: Bool {get}
    
    func restartGame()
    
    func startNewRound()
    
    func calculateScore(selectedValue playerValue: Int)
}

class Game: GameProtocol {
    var score: Int = 0
    private var minSecretValue: Int
    private var maxSecretValue: Int
    var currentSecretValue: Int = 0
    var round: Int
    var insertedNumberOfRounds: Int
    
    var isGameEnded: Bool {
        if round > insertedNumberOfRounds {
            return true
        } else {
            return false
        }
    }
    
    init?(startValue: Int, endValue: Int, totalGameRounds: Int, round: Int) {
        guard startValue <= endValue && totalGameRounds > 0 else {return nil}
        minSecretValue = startValue
        maxSecretValue = endValue
        self.round = round
        insertedNumberOfRounds = totalGameRounds
        currentSecretValue = getNewSecretValue()
    }
    

    func restartGame() {
        round = 0
        score = 0
        startNewRound()

    }
    
    func startNewRound() {
        currentSecretValue = getNewSecretValue()
        round += 1
    }
    
    
    private func getNewSecretValue() -> Int {
        (minSecretValue...maxSecretValue).randomElement()!
    }
    
    func calculateScore(selectedValue playerValue: Int) {
        if playerValue > currentSecretValue {
            score += 50 - playerValue + currentSecretValue
        } else if playerValue < currentSecretValue {
            score += 50 - currentSecretValue + playerValue
        } else {
            score += 50
        }
    }
}
