//
//  ViewController.swift
//  Right on target
//
//  Created by Aleksandr Malinin on 01.06.2021.
//

import UIKit

class ViewController: UIViewController {
    
    var game: Game!

    @IBOutlet var slider: UISlider!
    @IBOutlet var label: UILabel!
    @IBOutlet weak var insertedNumberOfRounds: UITextField!
    
    
    override func loadView() {
        super.loadView()
        
        let versionLabel = UILabel(frame: CGRect(x: 25, y: 15, width: 100, height: 20))
        versionLabel.textColor = UIColor.systemGray
        versionLabel.text = "Version 1.2"
        self.view.addSubview(versionLabel)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        game = Game(startValue: 1, endValue: 50, totalGameRounds: 1, round: 1)
        updateLabels()
    }
    
    // MARK: interaction between View and Model
    @IBAction func checkNumber() {
        let insertedValue = Int(insertedNumberOfRounds.text!) ?? 1
        game.insertedNumberOfRounds = insertedValue
        let sliderValue = Int(slider.value)
        game.calculateScore(selectedValue: sliderValue)
        game.startNewRound()
        updateLabels()
        if game.isGameEnded {
            showAlert(gameScore: game.score)
            game.restartGame()
            updateLabels()
            }
    }
    
    // MARK: update of the VIEW elements
    func updateLabels() {
        label.text = String(game.round)
    }
    
    // MARK: alert message
    func showAlert(gameScore: Int) {
        let alert = UIAlertController(title: "Game over", message: "Your score is \(gameScore)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "New game", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    // MARK: transition to another scene
    @IBAction func aboutButton() {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let secondViewController = storyBoard.instantiateViewController(withIdentifier: "SceneTwoViewController")
        self.present(secondViewController, animated: true, completion: nil)
    }
    
}

